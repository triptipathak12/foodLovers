const mongoose = require('mongoose');
const mongoURI = 'mongodb://angeltripti125:Rupika125$@ac-sl0jz61-shard-00-00.1zqkodi.mongodb.net:27017,ac-sl0jz61-shard-00-01.1zqkodi.mongodb.net:27017,ac-sl0jz61-shard-00-02.1zqkodi.mongodb.net:27017/foodlovers125?ssl=true&replicaSet=atlas-1wog56-shard-0&authSource=admin&retryWrites=true&w=majority'

const mongoDB = async () => {
    try {
        await mongoose.connect(mongoURI, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });

        console.log("Connected to MongoDB");

        const fetched_data = await mongoose.connection.db.collection("food_item");
        const data = await fetched_data.find({}).toArray();
        const food_category = await mongoose.connection.db.collection("food_category");
        const catData = await food_category.find({}).toArray();
        global.food_item = data;
        global.food_category = catData;

    } catch (error) {
        console.error("Error connecting to MongoDB:", error);
    }
};

module.exports = mongoDB;